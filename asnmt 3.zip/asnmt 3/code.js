function valCheck(){

    // for mobile number
    var mobno=document.getElementById("mob_num").value;
    if(mobno==""){
        document.getElementById("num_error").innerHTML="** Please fill the mobile number";
        return false;
    }

    if(mobno.length<13){
        document.getElementById("num_error").innerHTML="** mobile number must be 11 digits long";
        return false;
    }

    if(mobno.length>13){
        document.getElementById("num_error").innerHTML="** mobile number must be 11 digits long";
        return false;
    }

    if(mobno.charAt(0)!='+'){
        document.getElementById("num_error").innerHTML="** Enter valid mobile number";
        return false;
    }

    if(isNaN(mobno)){
        document.getElementById("num_error").innerHTML="** Only number is required";
        return false;
    }

    //for email
   // var email=document.getElementById("user_email").value;

    //if(email==""){
        //document.getElementById("email_error").innerHTML="** Please fill the Email";
       // return false;
   // }

    //if(email.indexOf('@')<=0){
      //  document.getElementById("email_error").innerHTML="** invalid @ position";
      //  return false;
   // }

    //var characters = /-,/;

    // if(email.match('-,')){
    //     document.getElementById("email_error").innerHTML="** you entered invalid characters";
    //     return false;
    // }
    function validateEmail(email) {
        // Check for more than one "@" symbol
        if (email.split('@').length !== 2) {
          return false;
        }
        
        // Check for comma (",") or hyphen ("-")
        if (email.includes(',') || email.includes('-')) {
          return false;
        }
        
        // Check for consecutive dots (".")
        if (email.includes('..')) {
          return false;
        }
        
        // Check for maximum two dots (".") and two or three characters after each dot
        const dotCount = email.split('.').length - 1;
        if (dotCount > 2) {
          return false;
        }
        
        const parts = email.split('.');
        for (let i = 0; i < parts.length; i++) {
          if (parts[i].length < 2 || parts[i].length > 3) {
            return false;
          }
        }
        if (email === '') {
            document.getElementById("emial_error").innerHTML="** Please fill the email section";
        return false;
           
          }
        
        return true;
      }



    //for username
var username=document.getElementById("user_name").value;

    if(username.charAt(0)!=username.charAt(0).toUpperCase()){
        document.getElementById("name_error").innerHTML="** First letter must be capital";
        return false;
    }

    if(username.length<8){
        document.getElementById("name_error").innerHTML="** User name must have 8 characters or more";
        return false;
    }

    var leter=/[0-9]/;
    if(!username.match(leter)){
        document.getElementById("name_error").innerHTML="** User name must contain atleast one digit";
        return false;
    }

    var letterNumber = /[0-9a-zA-Z]_/;

    if(!username.match(letterNumber)){
        document.getElementById("name_error").innerHTML="** invalid user name";
        return false;
    }

}


// function validateForm() {
//     // Get the form values
//     var number = document.getElementById("mob_num").value;
//     var email = document.getElementById("user_email").value;
//     var name = document.getElementById("name_error").value;
//    // var confirmPassword = document.forms["registrationForm"]["confirmPassword"].value;
    
//     // Check that all required fields are filled out
//     if (number == "" || email == "" || name == "") {
//       alert("All fields are required. Please complete the form.");
//       return false;
//     }
    
//     // Check that the email is properly formatted
//     if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
//       alert("Please enter a valid email address.");
//       return false;
//     }
    
//     // Check that the password and confirm password fields match
//     if (password != confirmPassword) {
//       alert("The password and confirm password fields do not match.");
//       return false;
//     }
    
//     // If all validation checks pass, submit the form
//     return true;
//   }